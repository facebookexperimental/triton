#!/usr/bin/env bash
set -euo pipefail
# Run from repository root after verifying GPU0 is idle; use a new output root.
repeat_root=experiments/fp8-kv-decode/results/new_repeat_lengths
docker exec -e CUDA_VISIBLE_DEVICES=0 -e PYTHONPATH=/tmp/tlx-current \
  -e FP8_REFERENCE_ROOT=/references/current adkankar-tlx-opt-20261105 \
  python experiments/fp8-kv-decode/compare_framework_decode.py \
  --repeat-only --aiter-companion --case gqa2304_shared gqa8192_shared gqa32768_shared \
  --extend-from experiments/fp8-kv-decode/results/2026-11-05_framework_decode/framework_routes \
  --output "$repeat_root/shared_verified"
docker exec -e CUDA_VISIBLE_DEVICES=0 -e PYTHONPATH=/tmp/tlx-current \
  -e FP8_REFERENCE_ROOT=/references/current adkankar-tlx-opt-20261105 \
  python experiments/fp8-kv-decode/compare_framework_decode.py \
  --repeat-only --case gqa2304_per-head gqa8192_per-head gqa32768_per-head \
  --extend-from experiments/fp8-kv-decode/results/2026-11-05_framework_decode/final \
  --output "$repeat_root/native"
