# FP8 KV decode experiments

This directory records the development of the gfx1250 TLX tutorial in
[`amd_pa_decode_fp8.py`](../../third_party/tlx/tutorials/amd_pa_decode_fp8.py).
The contract is E4M3FN KV with separate per-head scales, BF16 or FP8 Q, and BF16
attention output before projection.

- [Final optimization report](OPTIMIZATION_2026-11-09.md): measured gains,
  remaining AITER-favored cases, and fresh SGLang/vLLM controls.
- [Experiment ledger](FP8_KV_DECODE_ATTN.md): dated hypotheses, reasoning,
  validation, results, and rejected attempts.
- [Reproduction](REPRODUCE.md): environment, pinned sources, test commands,
  benchmarks, and chart generation.
- [References](REFERENCES.md): kernel capabilities and framework routing.

`charts/` contains the comparison figures; `results/` contains portable timing
records, CSV/JSON summaries, test reports, profiler analyses, and dated source
snapshots. The large raw ATT/PMC trees, decoder UI output, binary code objects,
counter listings, and duplicate external-source audits are local artifacts and
are excluded from Git. Paths to those local captures in older records document
their original locations; their summaries and source revisions remain included.

Source snapshots under `results/` and `snapshots/` are historical evidence. Do
not reformat them or reinterpret a snapshot as the current implementation.
The three complete repeated matrices exceed the usual 500 KiB hook limit but
are each below 1 MiB; the pre-commit exception names those records explicitly.
